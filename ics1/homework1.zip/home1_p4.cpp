#include <stdio.h>
int compose(int b, int a)
{
    int x=0xffff0000;
    x=x&a;
    int y=0x0000ffff;
    y=y&b;
    return x|y;
    }
int main()
{
    int x;
    int y;
    scanf("%x %x",&x,&y);
    printf("%x %x %x",x,y,compose(x,y));
    return 0;
}