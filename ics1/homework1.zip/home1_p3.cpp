#include<stdio.h>
int all1(int i)
{
while(i != 0){
    if((i&1) != 1){
        return 0;
    }
    i=i>>1;
}
return 1;
}
int all0(int i)
{
    if (i==0)
    return 1;
    return 0;
}
int least1(int i)
{
    if((i&1)==1){
        return 1;
    }
    return 0;
}
int least0(int i)
{
    if((i&1)==1){
        return 0;
    }
    return 1;
}
int main()
{int i=0;
scanf("%d",&i);
printf("%d %d %d %d",all1(i),all0(i),least0(i),least1(i));
return 0;
}