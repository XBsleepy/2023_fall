#include <iostream>
#include <chrono>
#include "opt.h"
using namespace std;
using namespace chrono;


void make()
{
    size_t size = 10000000;
    Table.num = size;
    Table.quantity = (int*)calloc(size, sizeof(int));
    Table.price = (int*)calloc(size, sizeof(int));
    Table.discount = (double*)calloc(size, sizeof(double));
    Table.tax = (double*)calloc(size, sizeof(double));
    Table.date = (int*)calloc(size, sizeof(int));

    for (size_t a = 0; a < size; ++a)
    {
        Table.quantity[a] = rand() % 10 + 10;
        Table.price[a] = rand() % 10 + 20;
        Table.discount[a] = (double)(rand() % 40 + 10) / 100;
        Table.tax[a] = (double)(rand() % 10 + 1) / 100;
        Table.date[a] = a % 100 + 1;
    }
}

int main()
{
    make();
    auto start = system_clock::now();
    calculate1(50);
    auto end = system_clock::now();
    auto duration = duration_cast<microseconds>(end - start);
    cout << "NO SIMD cost " << ((double)duration.count() * microseconds::period::num / microseconds::period::den) << " seconds" << endl;

    start = system_clock::now();
    calculate2(50);
    end = system_clock::now();
    duration = duration_cast<microseconds>(end - start);
    cout << "SIMD cost " << ((double)duration.count() * microseconds::period::num / microseconds::period::den) << " seconds" << endl;
    return 0;
}