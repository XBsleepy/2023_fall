int uadd_ok(unsigned x,unsigned y)
{
    unsigned temp=x+y;//get the result of x+y.
    if(temp<x)
    //if x+y<x or x+y<y means there is an overflow problem.
    //in fact the two situations will happen simutaniously,
    // so we just need to judge either of them.
    {
        return 1;
    }
    else{
        return 0;
    }
}
