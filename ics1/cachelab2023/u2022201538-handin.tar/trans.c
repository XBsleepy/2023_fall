#include <stdio.h>
#include "cachelab.h"

// 函数声明
int is_transpose(int M, int N, int A[N][M], int B[M][N]);

// 描述简单行扫描转置
void trans1(int M, int N, int A[N][M], int B[M][N])
{
    int k = 8;
    for (int i1 = 0; i1 < M; i1 += k)
    {
        for (int j1 = 0; j1 < N; j1 += k)
        {
            for (int i2 = i1; i2 < i1 + k; i2 ++)
            {
                // 从A矩阵中加载8个元素到寄存器
                int a1 = A[i2][j1], a2 = A[i2][j1 + 1], a3 = A[i2][j1 + 2], a4 = A[i2][j1 + 3], a5 = A[i2][j1 + 4], a6 = A[i2][j1 + 5], a7 = A[i2][j1 + 6], a8 = A[i2][j1 + 7];
                // 将元素存储到B矩阵对应位置
                B[j1][i2] = a1;
                B[j1 + 1][i2] = a2;
                B[j1 + 2][i2] = a3;
                B[j1 + 3][i2] = a4;
                B[j1 + 4][i2] = a5;
                B[j1 + 5][i2] = a6;
                B[j1 + 6][i2] = a7;
                B[j1 + 7][i2] = a8;
            }
        }
    }
}

// 描述按块转置
void trans2(int M, int N, int A[M][N], int B[M][N])
{
    int a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7;
    for (int i = 0; i < M; i += 8)
    {
        for (int j = 0; j < N; j += 8)
        {
            for (int temp = 0; temp < 4; temp++)
            {
                // 从A矩阵中加载8个元素到寄存器，是左上角和右上角
                a_0 = A[i + temp][j];
                a_1 = A[i + temp][j + 1];
                a_2 = A[i + temp][j + 2];
                a_3 = A[i + temp][j + 3];
                a_4 = A[i + temp][j + 4];
                a_5 = A[i + temp][j + 5];
                a_6 = A[i + temp][j + 6];
                a_7 = A[i + temp][j + 7];
                // 将元素存储到B矩阵对应位置,分别是左下角和右上角
                B[j][i + temp] = a_0;
                B[j + 1][i + temp] = a_1;
                B[j + 2][i + temp] = a_2;
                B[j + 3][i + temp] = a_3;
                B[j][i + temp + 4] = a_4;
                B[j + 1][i + temp + 4] = a_5;
                B[j + 2][i + temp + 4] = a_6;
                B[j + 3][i + temp + 4] = a_7;
            }
            for (int temp = 0; temp < 4; temp++)
            {
                // 处理左下角和右上角
                a_0 = B[j + temp][i + 4];
                a_1 = B[j + temp][i + 5];
                a_2 = B[j + temp][i + 6];
                a_3 = B[j + temp][i + 7];
                a_4 = A[i + 4][j + temp];
                a_5 = A[i + 5][j + temp];
                a_6 = A[i + 6][j + temp];
                a_7 = A[i + 7][j + temp];
                B[j + temp][i + 4] = a_4;
                B[j + temp][i + 5] = a_5;
                B[j + temp][i + 6] = a_6;
                B[j + temp][i + 7] = a_7;
                B[j + temp + 4][i] = a_0;
                B[j + temp + 4][i + 1] = a_1;
                B[j + temp + 4][i + 2] = a_2;
                B[j + temp + 4][i + 3] = a_3;
            }
            // 处理右下角的4x4矩阵
            for (int i1 = i + 4; i1 < i + 8; i1++)
            {
                for (int j1 = j + 4; j1 < j + 8; j1++)
                {
                    B[j1][i1] = A[i1][j1];
                }
            }
        }
    }
}

//直接分块16*16转置
void trans3(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, k, l;
    for (i = 0; i < N; i += 16)
    {
        for (j = 0; j < M; j += 16)
        {
            for (k = i; k < i + 16 && k < N; k++)
            {
                for (l = j; l < j + 16 && l < M; l++)
                {
                    // 执行基本的转置操作
                    B[l][k] = A[k][l];
                }
            }
        }
    }
}

// 描述提交的转置
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    if (N == 32)
        trans1(M, N, A, B);
    else if (N == 64)
        trans2(M, N, A, B);
    else
        trans3(M, N, A, B);
}

void registerFunctions()
{
    registerTransFunction(transpose_submit, transpose_submit_desc);
}

int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < M; ++j)
        {
            if (A[i][j] != B[j][i])
            {
                return 0;
            }
        }
    }
    return 1;
}
