#include "cachelab.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <getopt.h>
#include <string.h>

// 缓存参数
int s, E, b, S;  // s: 组索引位数, E: 每组的行数, b: 块偏移位数, S: 组数
char file[100];   // 存储内存访问轨迹的文件名

// 缓存统计数据
int hit_count = 0, miss_count = 0, eviction_count = 0;

// 全局计数器，用于缓存替换策略
int count = -1;

// 缓存行结构，用于存储标记和时间信息
struct Cache
{
    int tag;
    int time;
} **cache;

// 更新缓存，根据给定的内存地址
void update(unsigned addr)
{
    count--;
    unsigned tag = addr >> (b + s);
    unsigned set = addr << (64 - b - s) >> (64 - s);
    int empty_set = -1;
    int max = 1 << 31;
    int max_index = 0;

    // 遍历组内的缓存行
    for (int i = 0; i < E; i++)
    {
        // 检查标记是否匹配
        if (cache[set][i].tag == tag)
        {
            cache[set][i].time = count;  // 更新时间戳
            ++hit_count;
            return;
        }

        // 检查是否存在空缓存行
        if (cache[set][i].tag == -1 && empty_set == -1)
        {
            empty_set = i;
        }

        // 找到具有最大时间戳的缓存行
        if (cache[set][i].time > max)
        {
            max = cache[set][i].time;
            max_index = i;
        }
    }

    // 缓存未命中
    miss_count++;

    // 如果存在空缓存行，使用它
    if (empty_set != -1)
    {
        cache[set][empty_set].tag = tag;
        cache[set][empty_set].time = count;
        return;
    }

    // 替换具有最大时间戳的缓存行
    cache[set][max_index].tag = tag;
    cache[set][max_index].time = count;
    eviction_count++;
    return;
}

// 处理命令行选项
void option_choose(int argc, char *argv[])
{
    int opt = 0;
    while (-1 != opt)
    {
        opt = getopt(argc, argv, "s:E:b:t:");
        if (opt == 's')
        {
            s = atoi(optarg);
            S = 1 << s;  // 计算组数
        }
        else if (opt == 'E')
        {
            E = atoi(optarg);  // 设置每组的行数
        }
        else if (opt == 'b')
        {
            b = atoi(optarg);  // 设置块偏移位数
        }
        else if (opt == 't')
        {
            strcpy(file, optarg);  // 复制输入文件名
        }
    }
    return;
}

// 根据内存访问操作更新缓存
void update_arg(char op, unsigned addr)
{
    if (op == 'M' || op == 'L' || op == 'S')
        update(addr);
    if (op == 'M')
        hit_count++;  // 'M' 操作计为命中
}

// 从输入文件中读取内存访问轨迹
void readfile()
{
    FILE *fp;
    fp = fopen(file, "r");
    char operation;
    unsigned addr;

    // 处理文件中的每一行
    while (fscanf(fp, "%c %x", &operation, &addr) > 0)
    {
        update_arg(operation, addr);  // 根据内存访问操作更新缓存
    }
    fclose(fp);
    free(cache);
}

// 初始化缓存
void init_cache()
{
    cache = malloc(sizeof(struct Cache *) * S);

    // 为每个组分配内存并初始化缓存行
    for (int i = 0; i < S; i++)
    {
        cache[i] = malloc(sizeof(struct Cache) * S);
        for (int j = 0; j < S; j++)
        {
            cache[i][j].tag = -1;  // 将标记初始化为-1，表示空缓存行
            cache[i][j].time = 5;   // 初始化时间戳（任意初始值）
        }
    }
}

// 主函数
int main(int argc, char **argv)
{
    option_choose(argc, argv);  // 处理命令行选项
    init_cache();               // 初始化缓存
    readfile();                 // 读取内存访问轨迹并更新缓存
    printSummary(hit_count, miss_count, eviction_count);  // 打印缓存统计信息
    return 0;
}
