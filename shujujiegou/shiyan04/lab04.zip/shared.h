extern int p;
extern int h2;